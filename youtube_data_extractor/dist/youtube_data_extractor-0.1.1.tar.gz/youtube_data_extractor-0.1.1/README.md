# youtube_data_extractor

This is a package that allow you to extract useful information about any youtube video!

## Installation

```bash
$ pip install youtube_data_extractor
```

## Usage

- TODO

## Contributing

Interested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.

## License

`youtube_data_extractor` was created by YunhongFeng. It is licensed under the terms of the MIT license.

## Credits

`youtube_data_extractor` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).
